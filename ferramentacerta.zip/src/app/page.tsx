import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ToolCard from "@/components/ToolCard";
import { tools, categories, blogPosts } from "@/lib/data";
import { ArrowRight, CheckCircle2 } from "lucide-react";

export default function Home() {
  const featuredTools = tools.slice(0, 3);
  const recentPosts = blogPosts.slice(0, 2);

  return (
    <>
      <Header />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-blue-50 to-white py-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 max-w-4xl mx-auto leading-tight">
              As melhores ferramentas online para <span className="text-blue-600">pequenos negócios no Brasil</span>
            </h1>
            <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
              Compare sistemas, veja reviews honestos e escolha a melhor opção para sua empresa crescer sem gastar uma fortuna.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link 
                href="#melhores" 
                className="w-full sm:w-auto px-8 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
              >
                Ver Melhores Ferramentas
              </Link>
              <Link 
                href="/blog" 
                className="w-full sm:w-auto px-8 py-4 bg-white text-gray-700 border border-gray-200 rounded-xl font-bold hover:bg-gray-50 transition-colors"
              >
                Ler Guias e Dicas
              </Link>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section id="categorias" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold text-center mb-12">O que você está procurando?</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {categories.map((cat) => (
                <Link 
                  key={cat.id} 
                  href={`/category/${cat.slug}`}
                  className="group p-6 rounded-2xl border border-gray-100 bg-gray-50 hover:bg-blue-50 hover:border-blue-100 transition-all text-center"
                >
                  <h3 className="font-bold text-gray-900 mb-2 group-hover:text-blue-700">{cat.name}</h3>
                  <p className="text-sm text-gray-500 group-hover:text-blue-600/80">{cat.description}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Tools */}
        <section id="melhores" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex items-end justify-between mb-10">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Destaques da Semana</h2>
                <p className="text-gray-500">Ferramentas testadas e aprovadas pela nossa equipe.</p>
              </div>
              <Link href="/category/all" className="hidden md:flex items-center text-blue-600 font-medium hover:underline">
                Ver todas <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {featuredTools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>
            
            <div className="mt-8 text-center md:hidden">
              <Link href="/category/all" className="text-blue-600 font-medium hover:underline">
                Ver todas as ferramentas
              </Link>
            </div>
          </div>
        </section>

        {/* Value Prop */}
        <section className="py-16 bg-white border-y border-gray-100">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2">Reviews Honestos</h3>
                <p className="text-gray-500 text-sm">Testamos as ferramentas de verdade, sem copiar e colar do site do fabricante.</p>
              </div>
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2">Foco no Brasil</h3>
                <p className="text-gray-500 text-sm">Analisamos preços em Real, suporte em português e nota fiscal.</p>
              </div>
              <div className="p-6">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 text-purple-600">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2">Pequenos Negócios</h3>
                <p className="text-gray-500 text-sm">Tudo pensado para quem está começando ou quer escalar sem burocracia.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Blog Preview */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-8">Últimos Guias</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {recentPosts.map((post) => (
                <Link key={post.id} href={`/blog/${post.slug}`} className="block bg-white p-8 rounded-xl border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="text-sm text-gray-400 mb-2">{post.date}</div>
                  <h3 className="text-xl font-bold mb-3 text-gray-900">{post.title}</h3>
                  <p className="text-gray-500 mb-4">{post.excerpt}</p>
                  <span className="text-blue-600 font-medium text-sm">Ler artigo completo</span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
