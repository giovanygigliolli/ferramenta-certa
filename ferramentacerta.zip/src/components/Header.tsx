import Link from 'next/link';
import { Menu, Search } from 'lucide-react';

export default function Header() {
  return (
    <header className="border-b border-gray-100 bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="font-bold text-xl text-blue-600 flex items-center gap-2">
          <span>FerramentaCerta</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
          <Link href="/#categorias" className="hover:text-blue-600 transition-colors">Categorias</Link>
          <Link href="/blog" className="hover:text-blue-600 transition-colors">Blog</Link>
          <Link href="/sobre" className="hover:text-blue-600 transition-colors">Sobre</Link>
        </nav>

        <div className="flex items-center gap-4">
          <button className="md:hidden p-2">
            <Menu className="w-6 h-6 text-gray-600" />
          </button>
          <Link 
            href="/#melhores" 
            className="hidden md:block bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Ver Melhores
          </Link>
        </div>
      </div>
    </header>
  );
}
