import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100 pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-lg mb-4 text-blue-600">FerramentaCerta</h3>
            <p className="text-gray-500 text-sm">
              Ajudamos pequenos negócios a encontrarem as melhores ferramentas online. Reviews honestos e comparações diretas.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Categorias</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              <li><Link href="/category/sistemas-de-gestao" className="hover:text-blue-600">Sistemas de Gestão</Link></li>
              <li><Link href="/category/criadores-de-sites" className="hover:text-blue-600">Criadores de Sites</Link></li>
              <li><Link href="/category/ferramentas-de-agendamento" className="hover:text-blue-600">Agendamento</Link></li>
              <li><Link href="/category/plataformas-de-pagamento" className="hover:text-blue-600">Pagamentos</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              <li><Link href="/termos" className="hover:text-blue-600">Termos de Uso</Link></li>
              <li><Link href="/privacidade" className="hover:text-blue-600">Política de Privacidade</Link></li>
              <li><Link href="/sobre" className="hover:text-blue-600">Sobre Nós</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Contato</h4>
            <p className="text-sm text-gray-500">contato@ferramentacerta.com.br</p>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} Ferramenta Certa. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
